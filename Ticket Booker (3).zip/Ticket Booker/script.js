// script.js
document.addEventListener("DOMContentLoaded", function() {
    const ticketList = document.getElementById("ticketList");
    const bookingForm = document.getElementById("bookingForm");
  
    const tickets = [
      { name: "Concert Ticket", price: 50 },
      { name: "Movie Ticket", price: 15 },
      { name: "Sports Event Ticket", price: 30 }
    ];
  
    function displayTickets() {
      ticketList.innerHTML = "";
      tickets.forEach((ticket, index) => {
        const listItem = document.createElement("li");
        listItem.textContent = `${ticket.name} - $${ticket.price}`;
        ticketList.appendChild(listItem);
      });
    }
  
    function bookTicket(name, quantity) {
      const totalPrice = tickets.reduce((acc, ticket) => {
        if (ticket.name === name) {
          return acc + ticket.price * quantity;
        }
        return acc;
      }, 0);
      alert(`Total Price: $${totalPrice}`);
    }
  
    displayTickets();
  
    bookingForm.addEventListener("submit", function(event) {
      event.preventDefault();
      const name = document.getElementById("name").value;
      const quantity = parseInt(document.getElementById("quantity").value);
      if (quantity > 0) {
        bookTicket(name, quantity);
      } else {
        alert("Please enter a valid quantity.");
      }
    });
  });
  